

// Preloader 

	$(window).load(function() { 
	 if (screen.width < 768) {
		$('body').scrollspy({ offset: 55, target: '.navbar' });
		
	 }
	 else {
		$('body').scrollspy({ offset: 120, target: '.navbar' });
	 }
	 
	$('#status').fadeOut(); 
	$('#preloader').delay(350).fadeOut('slow'); 
	$('body').delay(350).css({'overflow':'visible'});
	
// Drop down close	

	$(".navbar li a").click(function(event) {
		// check if window is small enough so dropdown is created
	$(".navbar-collapse").removeClass("in").addClass("collapse");
	});
	
	})

	

	
// Smooth scrolling sections

	$('a[href*=#]:not([href=#])').click(function() {
		if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
		  var target = $(this.hash);
		  target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
		  if (target.length) {
		  	if (screen.width < 768) {
				$('html,body').animate({
				scrollTop: target.offset().top - 50
				}, 1000);
		
	 		}
	 		else {
				$('html,body').animate({
			  	scrollTop: target.offset().top - 105
				}, 1000);
	 		}	
			
			return false;
		  }
		}
	});
	
	
/* ==============================================
Google Map Styles
=============================================== */		
window.onload = function () {

			'use strict';

			var latlng = new google.maps.LatLng(51.522727, -0.085321);

			var styles = [ 

						 {
							"featureType": "road",
							"stylers": [
							  { "color": "#000000" }
							]
						  },{
							"featureType": "landscape",
							"stylers": [
							  { "color": "#141414" }
							]
						  },{
							"elementType": "labels.text.fill",
							"stylers": [
							  { "color": "#808080" }
							]
						  },{
							"featureType": "poi",
							"stylers": [
							  { "color": "#161616" }
							]
						  },{
							"elementType": "labels.text",
							"stylers": [
							  { "saturation": 1 },
							  { "weight": 0.1 },
							  { "color": "#7f8080" }
							]
						  },{
						  }
						  
						  ];


			var myOptions = {
				zoom: 17,
				center: latlng,
				mapTypeId: google.maps.MapTypeId.ROADMAP,
				disableDefaultUI: true,
				scrollwheel: false,
				styles: styles
			};
			
			 var contentString = '<div id="content">'+
			  '<div id="siteNotice">'+
			  '</div>'+
			  '<h4>We Are Here</h4>'+
			  '<p>Description' +
			  '</p>'+
			  '</div>';

		  var infowindow = new google.maps.InfoWindow({
			  content: contentString
		  });
			
			var map = new google.maps.Map(document.getElementById('map'), myOptions);
			
			var myLatlng = new google.maps.LatLng(43.04476,-76.124331);
			
			var image = 'images/marker.png';
			var marker = new google.maps.Marker({
				  position: myLatlng,
				  map: map,
				  title: 'Hello World!',
				  icon: image
			  });
			  
			 google.maps.event.addListener(marker, 'click', function() {
				infowindow.open(map,marker);
			  });
		
		}
	
		
  

